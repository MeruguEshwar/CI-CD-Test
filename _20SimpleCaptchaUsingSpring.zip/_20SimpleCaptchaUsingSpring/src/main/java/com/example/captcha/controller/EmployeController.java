package com.example.captcha.controller;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.captcha.Application;
import com.example.captcha.model.Employee;
import com.example.captcha.service.EmployeService;
import com.example.captcha.util.CaptchaUtil;

import cn.apiclub.captcha.Captcha;

@RestController
@RequestMapping("/Employe")
@CrossOrigin("http://localhost:3000/")
public class EmployeController {

	@Autowired
	private EmployeService empservice;

	@GetMapping("/test")
	private ResponseEntity<?> setupcaptcha(Employee e, HttpServletResponse resp) {
		Captcha cap = CaptchaUtil.createcaptcha(20, 100);
		e.setHidden(cap.getAnswer());
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_TYPE, org.springframework.http.MediaType.IMAGE_JPEG_VALUE);
		resp.setHeader("Content-Disposition", "attachement; filename=" + cap.getAnswer() + ".png");
		e.setCaptcha("");// user entered captcha
		// e.setImage(CaptchaUtil.encodeBase64(cap));
		// String res = ;

		ResponseEntity<byte[]> response = new ResponseEntity<byte[]>(CaptchaUtil.encodeBase64(cap), headers,
				HttpStatus.OK);
		return response;
	}

	@PostMapping("/register")
	public String register(@RequestBody Employee emp) {

		System.out.println("outside executing..");
		int empl = empservice.createEmployes(emp);
//		if(emp.getCaptcha().equals(emp.getHidden())) {
//			int empl = empservice.createEmployes(emp);
//			System.out.println("inside executing..");
//		}
		// setupcaptcha(emp);

		String msg = "";
		if (msg != null) {
			return "inserted successfully";
		} else {
			return "not inserted";
		}
	}
}
